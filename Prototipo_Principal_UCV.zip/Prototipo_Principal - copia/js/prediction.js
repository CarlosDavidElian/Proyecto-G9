/**
 * Módulo de Predicción de Radiación UV
 * Maneja la lógica para la sección de predicción de radiación UV
 */

document.addEventListener('DOMContentLoaded', function() {
    // Elementos del DOM
    const yearSelect = document.getElementById('year-select');
    const monthSelect = document.getElementById('month-select');
    const daySelect = document.getElementById('day-select');
    const predictButton = document.getElementById('predict-button');
    const predictButtonLoader = document.getElementById('predict-button-loader');
    const predictionInitialState = document.getElementById('prediction-initial-state');
    const predictionResults = document.getElementById('prediction-results');
    const uvIndexValue = document.getElementById('uv-index-value');
    const uvLevel = document.getElementById('uv-level');
    const solarRadiation = document.getElementById('solar-radiation');
    const riskLevel = document.getElementById('risk-level');
    const riskDescription = document.getElementById('risk-description');
    const weatherTemp = document.getElementById('weather-temp');
    const weatherHumidity = document.getElementById('weather-humidity');
    const weatherClouds = document.getElementById('weather-clouds');
   
    const samplePredictionData = {
        uvIndex: 8.5,
        solarRadiation: 1250,
        temperature: 22,
        humidity: 65,
        cloudCover: 30,
        risk: 'Alto',
        riskDesc: 'Riesgo alto de daño en la piel sin protección. Se recomienda protección solar extrema.'
    };

    // Inicialización
    function init() {
        // Inicializar selectores de fecha
        initializeDateSelectors();
        
        // Configurar event listeners
        setupEventListeners();
        
        // Inicializar gráfico vacío
        initializeChart();
        
        // Inicializar el mapa de calor con valores por defecto
        if (document.getElementById('heatmap')) {
            setTimeout(() => {
                initHeatMap(5); // Valor UV por defecto
            }, 1000); // Pequeño retraso para asegurar que todo esté cargado
        }
    }

    // Configurar años (últimos 5 años y próximos 5 años)
    function initializeDateSelectors() {
        const currentYear = new Date().getFullYear();
        for (let year = currentYear - 2; year <= currentYear + 2; year++) {
            const option = document.createElement('option');
            option.value = year;
            option.textContent = year;
            yearSelect.appendChild(option);
        }

        // Configurar meses
        const months = [
            'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
            'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
        ];

        months.forEach((month, index) => {
            const option = document.createElement('option');
            option.value = index + 1;
            option.textContent = month;
            monthSelect.appendChild(option);
        });

        // Configurar días (se actualizarán según el mes y año seleccionados)
        updateDays();

        // Event listeners
        yearSelect.addEventListener('change', updateDays);
        monthSelect.addEventListener('change', updateDays);
        predictButton.addEventListener('click', handlePrediction);
    }


    // Actualizar los días disponibles según el mes y año seleccionados
    function updateDays() {
        // Habilitar/deshabilitar selectores según corresponda
        monthSelect.disabled = !yearSelect.value;
        daySelect.disabled = !monthSelect.value || !yearSelect.value;
        predictButton.disabled = !daySelect.value;

        // Actualizar clases de estilo
        monthSelect.classList.toggle('opacity-50', !yearSelect.value);
        monthSelect.classList.toggle('cursor-not-allowed', !yearSelect.value);
        daySelect.classList.toggle('opacity-50', !monthSelect.value || !yearSelect.value);
        daySelect.classList.toggle('cursor-not-allowed', !monthSelect.value || !yearSelect.value);

        if (!yearSelect.value || !monthSelect.value) {
            daySelect.innerHTML = '<option value="">Seleccione un día</option>';
            return;
        }

        // Obtener el número de días en el mes seleccionado
        const year = parseInt(yearSelect.value);
        const month = parseInt(monthSelect.value);
        const daysInMonth = new Date(year, month, 0).getDate();

        // Actualizar opciones de días
        daySelect.innerHTML = '<option value="">Seleccione un día</option>';
        for (let day = 1; day <= daysInMonth; day++) {
            const option = document.createElement('option');
            option.value = day;
            option.textContent = day;
            daySelect.appendChild(option);
        }
    }

    // Mostrar/ocultar pantalla de carga de predicción
    function togglePredictionLoading(show, message = '') {
        const loadingScreen = document.getElementById('predictionLoading');
        if (loadingScreen) {
            if (message) {
                const messageEl = loadingScreen.querySelector('p:first-of-type');
                if (messageEl) messageEl.textContent = message;
            }
            loadingScreen.classList.toggle('hidden', !show);
            loadingScreen.classList.toggle('flex', show);
        }
    }

    // Mostrar pantalla de carga de predicción
    function showPredictionLoading(show, message = '') {
        const loadingScreen = document.getElementById('predictionLoading');
        if (!loadingScreen) return;
        
        if (show) {
            if (message) {
                const messageEl = loadingScreen.querySelector('.loading-message');
                if (messageEl) messageEl.textContent = message;
            }
            loadingScreen.classList.remove('hidden');
            document.body.style.overflow = 'hidden';
        } else {
            loadingScreen.classList.add('hidden');
            document.body.style.overflow = '';
        }
    }

    // Manejar la predicción
    async function handlePrediction() {
        if (!yearSelect.value || !monthSelect.value || !daySelect.value) return;

        // Mostrar pantalla de carga
        showPredictionLoading(true, 'Procesando los datos de predicción para la fecha seleccionada...');
        
        const predictBtn = document.getElementById('predict-button');
        predictBtn.innerHTML = `
            <div class="spinner"></div>
            <span>🔄 Ejecutando modelo para UV...</span>
        `;

        try {
            // Mostrar estado de carga
            predictButton.disabled = true;
            predictButtonLoader.classList.remove('hidden');
            predictButton.querySelector('span').textContent = 'Procesando...';

            await new Promise(resolve => setTimeout(resolve, 1500));
            
            // Mostrar resultados
            showPredictionResults(samplePredictionData);
            
            // Actualizar mensaje de carga final
            togglePredictionLoading(true, '¡Predicción completada! Cargando visualizaciones...');
            
        } catch (error) {
            console.error('Error al obtener la predicción:', error);
            showStatusMessage('❌ Error al procesar los resultados', 'error');
        } finally {
            // Ocultar pantalla de carga después de un pequeño retraso
            setTimeout(() => {
                togglePredictionLoading(false);
            }, 500);
            
            // Restaurar estado del botón
            predictButton.disabled = false;
            predictButtonLoader.classList.add('hidden');
            predictBtn.innerHTML = `
                <div class="text-2xl">🚀</div>
                Predecir Radiación UV
            `;
        }
    }

    // Actualizar el nivel de UV y recomendaciones
    function updateUvLevel(uvIndex) {
        let level = '';
        let bgColor = '';
        let textColor = '';
        let recommendations = [];

        if (uvIndex <= 2) {
            level = 'Bajo';
            bgColor = 'bg-green-500/10';
            textColor = 'text-green-400';
            recommendations = [
                'Puedes disfrutar del sol con seguridad.',
                'Usa gafas de sol en días brillantes.',
                'Considera usar protector solar si pasas mucho tiempo al aire libre.'
            ];
        } else if (uvIndex <= 5) {
            level = 'Moderado';
            bgColor = 'bg-yellow-500/10';
            textColor = 'text-yellow-400';
            recommendations = [
                'Usa protector solar SPF 30+ si estás al aire libre.',
                'Usa un sombrero y gafas de sol.',
                'Busca la sombra durante las horas pico de sol (10 AM - 4 PM).'
            ];
        } else if (uvIndex <= 7) {
            level = 'Alto';
            bgColor = 'bg-orange-500/10';
            textColor = 'text-orange-400';
            recommendations = [
                'Aplica protector solar SPF 30+ cada 2 horas.',
                'Usa ropa protectora y un sombrero de ala ancha.',
                'Busca la sombra durante las horas pico de sol (10 AM - 4 PM).',
                'Usa gafas de sol que bloqueen los rayos UV.'
            ];
        } else if (uvIndex <= 10) {
            level = 'Muy Alto';
            bgColor = 'bg-red-500/10';
            textColor = 'text-red-400';
            recommendations = [
                'Aplica protector solar SPF 50+ cada 2 horas y después de nadar o sudar.',
                'Usa ropa protectora, sombrero de ala ancha y gafas de sol.',
                'Permanece en la sombra durante las horas pico de sol (10 AM - 4 PM).',
                'Evita la exposición prolongada al sol.'
            ];
        } else {
            level = 'Extremo';
            bgColor = 'bg-purple-500/10';
            textColor = 'text-purple-400';
            recommendations = [
                'Evita la exposición al sol tanto como sea posible.',
                'Si debes salir, usa ropa protectora, sombrero y gafas de sol.',
                'Aplica protector solar SPF 50+ cada 2 horas.',
                'Permanece en la sombra en todo momento.',
                'Las quemaduras solares pueden ocurrir en menos de 15 minutos.'
            ];
        }

        // Actualizar UI
        uvLevel.textContent = level;
        uvLevel.className = `inline-block px-3 py-1 rounded-full text-xs font-semibold mt-2 ${bgColor} ${textColor}`;

        // Actualizar recomendaciones
        const recommendationsContainer = document.getElementById('uv-recommendations');
        if (recommendationsContainer) {
            recommendationsContainer.innerHTML = recommendations
                .map(rec => `
                    <div class="flex items-start">
                        <div class="flex-shrink-0 mt-1">
                            <div class="w-6 h-6 rounded-full ${textColor.replace('text', 'bg')} bg-opacity-20 flex items-center justify-center">
                                <i class="fas fa-check text-xs ${textColor}"></i>
                            </div>
                        </div>
                        <p class="ml-3 text-gray-300">${rec}</p>
                    </div>
                `)
                .join('');
        }
    }

    // Inicializar gráfico de radiación UV
    function initChart(uvIndex) {
        const ctx = document.getElementById('uv-chart').getContext('2d');
        
        // Datos de ejemplo para el gráfico (reemplazar con datos reales)
        const hours = Array.from({length: 24}, (_, i) => `${i}:00`);
        const uvData = Array.from({length: 24}, (_, i) => {
            // Simular datos de radiación UV a lo largo del día
            const hour = i;
            let value;
            
            if (hour < 6 || hour > 18) {
                value = 0; // Noche
            } else {
                // Crear una curva suave que alcance su punto máximo al mediodía
                const normalizedHour = (hour - 6) / 12; // 6 AM a 6 PM = 12 horas
                const peakTime = 0.5; // Mediodía
                const distanceFromPeak = Math.abs(normalizedHour - peakTime);
                value = uvIndex * (1 - Math.pow(distanceFromPeak / peakTime, 2));
                value = Math.max(0, Math.min(value, uvIndex)); // Asegurar valor entre 0 y uvIndex
            }
            
            return parseFloat(value.toFixed(2));
        });

        // Destruir instancia anterior del gráfico si existe
        if (window.uvChart) {
            window.uvChart.destroy();
        }

        // Crear nuevo gráfico
        window.uvChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: hours,
                datasets: [{
                    label: 'Índice UV',
                    data: uvData,
                    borderColor: 'rgba(251, 191, 36, 0.8)',
                    backgroundColor: 'rgba(251, 191, 36, 0.1)',
                    borderWidth: 2,
                    tension: 0.4,
                    fill: true,
                    pointBackgroundColor: 'rgba(251, 191, 36, 0.8)',
                    pointBorderColor: '#fff',
                    pointHoverRadius: 5,
                    pointHoverBackgroundColor: 'rgba(251, 191, 36, 1)',
                    pointHoverBorderColor: '#fff',
                    pointHitRadius: 10,
                    pointBorderWidth: 2,
                    pointRadius: 3
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(31, 41, 55, 0.95)',
                        titleColor: '#f3f4f6',
                        bodyColor: '#e5e7eb',
                        borderColor: 'rgba(75, 85, 99, 0.5)',
                        borderWidth: 1,
                        padding: 12,
                        callbacks: {
                            label: function(context) {
                                return `Índice UV: ${context.parsed.y.toFixed(1)}`;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: {
                            color: 'rgba(75, 85, 99, 0.3)',
                            drawBorder: false
                        },
                        ticks: {
                            color: '#9ca3af',
                            maxRotation: 0,
                            autoSkip: true,
                            maxTicksLimit: 12
                        }
                    },
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(75, 85, 99, 0.2)',
                            drawBorder: false
                        },
                        ticks: {
                            color: '#9ca3af',
                            precision: 0
                        }
                    }
                },
                elements: {
                    line: {
                        borderJoinStyle: 'round'
                    },
                    point: {
                        radius: 0,
                        hoverRadius: 6
                    }
                },
                interaction: {
                    intersect: false,
                    mode: 'index'
                },
                animation: {
                    duration: 1000,
                    easing: 'easeOutQuart'
                }
            }
        });
    }

    // Mostrar mensaje de error
    function showError(message) {
        // Implementar lógica para mostrar mensajes de error al usuario
        console.error(message);
        // Ejemplo: Mostrar un toast o notificación
        alert(message);
    }

    // Inicializar el módulo
    init();
});
