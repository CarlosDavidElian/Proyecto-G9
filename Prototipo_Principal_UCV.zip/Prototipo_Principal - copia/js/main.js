// Variables globales
let currentCacheKey = null;
let currentData = null;

// Esperar a que el DOM esté completamente cargado
document.addEventListener('DOMContentLoaded', function() {
    // Variables
    const menuToggle = document.querySelector('.mobile-menu');
    const menu = document.querySelector('.menu');
    const navLinks = document.querySelectorAll('.menu a');
    const header = document.querySelector('.header');
    const contactForm = document.getElementById('contact-form');
    const portfolioGrid = document.querySelector('.portfolio-grid');
    const fileInput = document.getElementById('file-input');
    const fileUploadBtn = document.getElementById('file-upload-btn');
    const fileNameDisplay = document.getElementById('file-name');
    const fileStatus = document.getElementById('file-status');
    const dateInput = document.getElementById('prediction-date');
    const departmentSelect = document.getElementById('department-select');
    const predictBtn = document.getElementById('predict-btn');
    const resultsDiv = document.getElementById('results');
    const loadingIndicator = document.getElementById('loading-indicator');
    const dateSelectionSection = document.getElementById('dateSelectionSection');

    // Variables de estado
    let currentCacheKey = null;
    let currentData = null;

    // Datos de ejemplo para el portafolio
    const portfolioItems = [
        {
            title: 'Proyecto 1',
            category: 'Diseño Web',
            image: 'img/portfolio1.jpg'
        },
        {
            title: 'Proyecto 2',
            category: 'Aplicación Móvil',
            image: 'img/portfolio2.jpg'
        },
        {
            title: 'Proyecto 3',
            category: 'Diseño Gráfico',
            image: 'img/portfolio3.jpg'
        },
        {
            title: 'Proyecto 4',
            category: 'Marketing Digital',
            image: 'img/portfolio4.jpg'
        },
        {
            title: 'Proyecto 5',
            category: 'Diseño Web',
            image: 'img/portfolio5.jpg'
        },
        {
            title: 'Proyecto 6',
            category: 'Aplicación Móvil',
            image: 'img/portfolio6.jpg'
        }
    ];

    // Función para inicializar los componentes
    function init() {
        setupMobileMenu();
        setupScrollEffects();
        setupForm();
        loadPortfolio();
    }

    // Configurar el menú móvil
    function setupMobileMenu() {
        if (menuToggle) {
            menuToggle.addEventListener('click', function() {
                menu.classList.toggle('active');
                this.classList.toggle('fa-times');
                this.classList.toggle('fa-bars');
            });
        }

        // Cerrar menú al hacer clic en un enlace
        navLinks.forEach(link => {
            link.addEventListener('click', function() {
                menu.classList.remove('active');
                document.querySelector('.mobile-menu').classList.remove('fa-times');
                document.querySelector('.mobile-menu').classList.add('fa-bars');
            });
        });
    }

    // Efectos de desplazamiento
    function setupScrollEffects() {
        // Cambiar el header al hacer scroll
        window.addEventListener('scroll', function() {
            if (window.scrollY > 100) {
                header.style.padding = '10px 0';
                header.style.background = 'rgba(255, 255, 255, 0.98)';
                header.style.boxShadow = '0 5px 15px rgba(0, 0, 0, 0.1)';
            } else {
                header.style.padding = '15px 0';
                header.style.background = 'white';
                header.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.1)';
            }
        });

        // Scroll suave para enlaces internos
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href');
                if (targetId === '#') return;
                
                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    window.scrollTo({
                        top: targetElement.offsetTop - 80,
                        behavior: 'smooth'
                    });
                }
            });
        });
    }

    // Configurar el formulario de contacto
    function setupForm() {
        if (contactForm) {
            contactForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                // Obtener los valores del formulario
                const formData = new FormData(this);
                const formValues = Object.fromEntries(formData.entries());
                
                // Aquí puedes agregar la lógica para enviar el formulario
                console.log('Datos del formulario:', formValues);
                
                // Mostrar mensaje de éxito
                alert('¡Mensaje enviado con éxito! Nos pondremos en contacto contigo pronto.');
                this.reset();
            });
        }
    }

    // Cargar proyectos en el portafolio
    function loadPortfolio() {
        if (!portfolioGrid) return;
        
        // Limpiar el contenedor
        portfolioGrid.innerHTML = '';
        
        // Generar elementos del portafolio
        portfolioItems.forEach(item => {
            const portfolioItem = document.createElement('div');
            portfolioItem.className = 'portfolio-item';
            portfolioItem.innerHTML = `
                <div class="portfolio-img">
                    <img src="${item.image}" alt="${item.title}" onerror="this.src='img/placeholder.jpg'">
                </div>
                <div class="portfolio-info">
                    <h3>${item.title}</h3>
                    <p>${item.category}</p>
                </div>
            `;
            
            portfolioGrid.appendChild(portfolioItem);
        });
    }

    // Inicializar la aplicación
    init();
    
    // Configurar manejadores de eventos
    console.log('Configurando manejadores de eventos...');
    
    // Configurar el botón de subir archivo
    if (fileUploadBtn) {
        console.log('Configurando manejador para el botón de subir archivo');
        fileUploadBtn.addEventListener('click', handleFileUpload);
    } else {
        console.error('No se encontró el botón de subir archivo');
    }
    
    // Obtener referencia al formulario de predicción
    const predictionForm = document.getElementById('prediction-form');
    
    // Configurar el formulario de predicción si existe
    if (predictionForm) {
        console.log('Configurando manejador para el formulario de predicción');
        predictionForm.addEventListener('submit', function(e) {
            e.preventDefault();
            console.log('Formulario de predicción enviado');
            handlePrediction(e);
        });
    } else {
        console.error('No se encontró el formulario de predicción');
    }
    
    // Configurar el botón de predicción directamente por si acaso
    if (predictBtn) {
        console.log('Configurando manejador directo para el botón de predicción');
        predictBtn.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('Botón de predicción clickeado');
            handlePrediction(e);
        });
    }
    
    // Establecer la fecha mínima como mañana
    if (dateInput) {
        const today = new Date();
        // Añadir un día para asegurar que sea mañana (ya que hoy ya está en el pasado)
        today.setDate(today.getDate() + 1);
        const tomorrow = today.toISOString().split('T')[0];
        dateInput.min = tomorrow;
        dateInput.value = tomorrow;
        console.log('Fecha mínima establecida a:', tomorrow);
    } else {
        console.error('No se encontró el campo de fecha');
    }
    
    // Mostrar mensaje de bienvenida
    console.log('Aplicación inicializada correctamente');
});

// Manejar la subida de archivos
async function handleFileUpload(e) {
    e.preventDefault();
    
    const file = fileInput.files[0];
    if (!file) {
        showMessage('Por favor selecciona un archivo Excel', 'error');
        return;
    }
    
    const formData = new FormData();
    formData.append('file', file);
    
    try {
        showLoading(true);
        const response = await fetch('http://localhost:5000/api/upload', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (response.ok) {
            currentCacheKey = data.cache_key;
            currentData = data;
            updateDepartmentSelect(data.departamentos);
            showMessage(`Archivo cargado exitosamente. ${data.total_registros} registros procesados.`, 'success');
            updateFileStatus(file.name, data.total_registros);
        } else {
            showMessage(data.error || 'Error al procesar el archivo', 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        showMessage('Error de conexión con el servidor', 'error');
    } finally {
        showLoading(false);
    }
}

// Manejar la predicción
async function handlePrediction(e) {
    e.preventDefault();
    
    if (!currentCacheKey) {
        showMessage('Por favor carga un archivo primero', 'error');
        return;
    }
    
    const fecha = dateInput.value;
    const departamento = departmentSelect.value;
    
    if (!fecha || !departamento) {
        showMessage('Por favor completa todos los campos', 'error');
        return;
    }
    
    try {
        showLoading(true);
        const response = await fetch('http://localhost:5000/api/predict', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                cache_key: currentCacheKey,
                fecha: fecha,
                departamento: departamento
            })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            // Mostrar resultados y navegar a la sección de resultados
            displayResults(data);
            
            // Hacer scroll suave a la sección de resultados
            const resultsSection = document.getElementById('dataDisplay');
            if (resultsSection) {
                resultsSection.scrollIntoView({ behavior: 'smooth' });
            }
            
            // Mostrar la sección de resultados si está oculta
            if (resultsSection && resultsSection.classList.contains('hidden')) {
                resultsSection.classList.remove('hidden');
            }
            
            // Mostrar mensaje de éxito
            showMessage('Predicción generada exitosamente', 'success');
        } else {
            showMessage(data.error || 'Error al realizar la predicción', 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        showMessage('Error de conexión con el servidor. Asegúrate de que el servidor backend esté en ejecución.', 'error');
    } finally {
        showLoading(false);
    }
}

// Actualizar el selector de departamentos
function updateDepartmentSelect(departamentos) {
    if (!departmentSelect) return;
    
    departmentSelect.innerHTML = '<option value="">Selecciona un departamento</option>';
    departamentos.forEach(depto => {
        const option = document.createElement('option');
        option.value = depto;
        option.textContent = depto;
        departmentSelect.appendChild(option);
    });
}

// Mostrar resultados de la predicción
function displayResults(data) {
    if (!resultsDiv) return;
    
    // Asegurarse de que la sección de resultados sea visible
    const resultsSection = document.getElementById('dataDisplay');
    if (resultsSection && resultsSection.classList.contains('hidden')) {
        resultsSection.classList.remove('hidden');
    }
    
    // Limpiar resultados anteriores
    resultsDiv.innerHTML = '';
    
    if (data.mensaje) {
        resultsDiv.innerHTML = `
            <div class="bg-blue-100 border-l-4 border-blue-500 text-blue-700 p-4 mb-4" role="alert">
                <p class="font-bold">Información</p>
                <p>${data.mensaje}</p>
            </div>`;
        return;
    }
    
    if (!data.datos) {
        resultsDiv.innerHTML = `
            <div class="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 mb-4" role="alert">
                <p class="font-bold">Advertencia</p>
                <p>No se encontraron datos para los criterios seleccionados</p>
            </div>`;
        return;
    }
    
    const datos = data.datos;
    const fecha = new Date(datos.FECHA).toLocaleDateString('es-ES', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
    
    // Crear el HTML de los resultados
    const resultHTML = `
        <div class="bg-white bg-opacity-10 backdrop-filter backdrop-blur-lg rounded-xl p-6 shadow-lg">
            <div class="border-b border-gray-200 pb-4 mb-6">
                <h3 class="text-2xl font-bold text-yellow-300">Resultados de la Predicción</h3>
                <p class="text-gray-300">${fecha} - ${datos.DEPARTAMENTO || 'N/A'}</p>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="bg-gray-800 bg-opacity-50 p-5 rounded-lg">
                    <h4 class="text-lg font-semibold text-yellow-200 mb-4 border-b border-yellow-500 pb-2">
                        <i class="fas fa-map-marker-alt mr-2"></i>Ubicación
                    </h4>
                    <div class="space-y-3">
                        <p class="text-gray-200">
                            <span class="font-medium">Latitud:</span> 
                            <span class="text-yellow-300">${datos.LATITUD ? datos.LATITUD.toFixed(4) : 'N/A'}</span>
                        </p>
                        <p class="text-gray-200">
                            <span class="font-medium">Longitud:</span> 
                            <span class="text-yellow-300">${datos.LONGITUD ? datos.LONGITUD.toFixed(4) : 'N/A'}</span>
                        </p>
                        <p class="text-gray-200">
                            <span class="font-medium">Altitud:</span> 
                            <span class="text-yellow-300">${datos.ALTITUD ? datos.ALTITUD.toFixed(2) + ' m.s.n.m' : 'N/A'}</span>
                        </p>
                    </div>
                </div>
                <div class="bg-gray-800 bg-opacity-50 p-5 rounded-lg">
                    <h4 class="text-lg font-semibold text-blue-200 mb-4 border-b border-blue-500 pb-2">
                        <i class="fas fa-cloud-sun mr-2"></i>Variables Climáticas
                    </h4>
                    <div class="space-y-3">
                        <p class="text-gray-200">
                            <span class="font-medium">Radiación UV Máxima:</span> 
                            <span class="text-blue-300 font-bold">${datos.UV_MAX ? datos.UV_MAX.toFixed(2) : 'N/A'}</span>
                        </p>
                        <p class="text-gray-200">
                            <span class="font-medium">Nivel de Ozono (O3):</span> 
                            <span class="text-blue-300">${datos.O3 ? datos.O3.toFixed(2) : 'N/A'}</span>
                        </p>
                        <p class="text-gray-200">
                            <span class="font-medium">Precipitación (PP):</span> 
                            <span class="text-blue-300">${datos.PP ? datos.PP.toFixed(2) + ' mm' : 'N/A'}</span>
                        </p>
                    </div>
                </div>
            </div>
            
            <!-- Sección de recomendaciones basadas en el índice UV -->
            ${datos.UV_MAX ? `
            <div class="mt-8 bg-gray-800 bg-opacity-50 p-5 rounded-lg">
                <h4 class="text-lg font-semibold text-green-200 mb-4 border-b border-green-500 pb-2">
                    <i class="fas fa-lightbulb mr-2"></i>Recomendaciones
                </h4>
                ${getUVRecommendations(datos.UV_MAX)}
            </div>` : ''}
        </div>`;
    
    // Insertar el HTML en el contenedor de resultados
    resultsDiv.innerHTML = resultHTML;
    
    // Función para obtener recomendaciones basadas en el índice UV
    function getUVRecommendations(uvIndex) {
        let recommendation = '';
        let icon = '';
        let color = '';
        
        if (uvIndex <= 2) {
            recommendation = 'Índice UV bajo. No se requiere protección.';
            icon = '😎';
            color = 'text-green-400';
        } else if (uvIndex <= 5) {
            recommendation = 'Índice UV moderado. Usa protección solar.';
            icon = '🧴';
            color = 'text-yellow-400';
        } else if (uvIndex <= 7) {
            recommendation = 'Índice UV alto. Toma precauciones, usa gorra y lentes de sol.';
            icon = '🧢';
            color = 'text-orange-400';
        } else if (uvIndex <= 10) {
            recommendation = 'Índice UV muy alto. Evita la exposición prolongada al sol.';
            icon = '☀️';
            color = 'text-red-400';
        } else {
            recommendation = 'Índice UV extremo. Evita la exposición al sol en lo posible.';
            icon = '⚠️';
            color = 'text-red-600';
        }
        
        return `
            <div class="flex items-center ${color} mb-2">
                <span class="text-2xl mr-3">${icon}</span>
                <p class="text-lg font-medium">${recommendation}</p>
            </div>
            <p class="text-gray-300 text-sm">
                Índice UV: <span class="font-bold">${uvIndex.toFixed(1)}</span> - ${getUVLevel(uvIndex)}
            </p>`;
    }
    
    // Función para obtener el nivel de UV
    function getUVLevel(uvIndex) {
        if (uvIndex <= 2) return 'Bajo';
        if (uvIndex <= 5) return 'Moderado';
        if (uvIndex <= 7) return 'Alto';
        if (uvIndex <= 10) return 'Muy Alto';
        return 'Extremo';
    }
}

// Actualizar estado del archivo
function updateFileStatus(filename, recordCount) {
    if (!fileStatus) return;
    
    fileStatus.innerHTML = `
        <div class="alert alert-success">
            <i class="fas fa-file-excel"></i>
            <strong>Archivo cargado:</strong> ${filename}<br>
            <small>${recordCount} registros disponibles</small>
        </div>
    `;
}

// Mostrar mensaje de estado
function showMessage(message, type = 'info') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
    alertDiv.role = 'alert';
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
    `;
    
    // Insertar al principio del contenedor de resultados
    if (resultsDiv) {
        resultsDiv.prepend(alertDiv);
    }
    
    // Cerrar automáticamente después de 5 segundos
    setTimeout(() => {
        const bsAlert = new bootstrap.Alert(alertDiv);
        bsAlert.close();
    }, 5000);
}

// Mostrar/ocultar indicador de carga
function showLoading(show) {
    if (!loadingIndicator) return;
    loadingIndicator.style.display = show ? 'block' : 'none';
}

// Animaciones al hacer scroll
window.addEventListener('scroll', revealOnScroll);

function revealOnScroll() {
    const reveals = document.querySelectorAll('.service, .about-content, .portfolio-item');
    
    for (let i = 0; i < reveals.length; i++) {
        const windowHeight = window.innerHeight;
        const revealTop = reveals[i].getBoundingClientRect().top;
        const revealPoint = 150;
        
        if (revealTop < windowHeight - revealPoint) {
            reveals[i].classList.add('active');
        }
    }
}

// Llamar a la función una vez al cargar la página
window.addEventListener('load', revealOnScroll);
