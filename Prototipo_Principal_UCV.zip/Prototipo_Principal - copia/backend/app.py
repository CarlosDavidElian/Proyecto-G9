import os
import joblib
import pandas as pd
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from datetime import datetime

app = Flask(__name__, static_folder='../', static_url_path='')
CORS(app)

# Configuración de rutas
UPLOAD_FOLDER = 'uploads'
CACHE_FOLDER = 'cache'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(CACHE_FOLDER, exist_ok=True)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['CACHE_FOLDER'] = CACHE_FOLDER

# Función para cargar y procesar datos
def cargar_datos(ruta_archivo, cache_key):
    cache_path = os.path.join(app.config['CACHE_FOLDER'], f"{cache_key}.pkl")
    
    # Verificar si los datos están en caché
    if os.path.exists(cache_path):
        print(f"📦 Cargando datos desde caché: {cache_path}")
        return joblib.load(cache_path)
    
    print(f"📂 Cargando datos desde: {ruta_archivo}")
    try:
        df = pd.read_excel(ruta_archivo)
        print(f"✅ Datos cargados exitosamente. Forma: {df.shape}")
        
        columnas_requeridas = ['FECHA', 'LONGITUD', 'LATITUD', 'ALTITUD', 'O3', 'UV_MAX', 'PP', 'DEPARTAMENTO']
        columnas_faltantes = [col for col in columnas_requeridas if col not in df.columns]
        
        if columnas_faltantes:
            print(f"❌ Error: Faltan columnas: {columnas_faltantes}")
            return None
        
        print("\n📊 Análisis de valores faltantes:")
        for col in columnas_requeridas:
            nan_count = df[col].isnull().sum()
            if nan_count > 0:
                print(f"  - {col}: {nan_count} valores NaN ({nan_count/len(df)*100:.1f}%)")
        
        if not pd.api.types.is_datetime64_any_dtype(df['FECHA']):
            df['FECHA'] = pd.to_datetime(df['FECHA'], errors='coerce')
        
        df = df.sort_values('FECHA')
        
        # Manejo de valores faltantes
        for col in ['LONGITUD', 'LATITUD', 'ALTITUD']:
            if df[col].isnull().any():
                df[col] = df[col].fillna(method='ffill').fillna(method='bfill')
                if df[col].isnull().any():
                    df[col] = df[col].fillna(df[col].median())
        
        for col in ['UV_MAX', 'O3', 'PP']:
            if df[col].isnull().any():
                df[col] = df[col].interpolate(method='linear')
                if df[col].isnull().any():
                    df[col] = df[col].fillna(df[col].median())
                if df[col].isnull().any():
                    df[col] = df[col].fillna(0)
        
        if df['DEPARTAMENTO'].isnull().any():
            df['DEPARTAMENTO'] = df['DEPARTAMENTO'].fillna(df['DEPARTAMENTO'].mode()[0])
        
        # Características temporales
        df['DIA_DEL_MES'] = df['FECHA'].dt.day
        df['MES'] = df['FECHA'].dt.month
        df['DIA_DEL_AÑO'] = df['FECHA'].dt.dayofyear
        
        # Guardar en caché
        joblib.dump(df, cache_path)
        print(f"💾 Datos guardados en caché: {cache_path}")
        
        return df
        
    except Exception as e:
        print(f"❌ Error al cargar datos: {e}")
        return None

# Ruta para subir archivos
@app.route('/api/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No se proporcionó ningún archivo'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'Nombre de archivo vacío'}), 400
    
    if file and file.filename.endswith(('.xlsx', '.xls')):
        filename = f"{int(datetime.now().timestamp())}_{file.filename}"
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        # Generar clave de caché única
        cache_key = f"data_{int(datetime.now().timestamp())}"
        
        # Procesar datos
        df = cargar_datos(filepath, cache_key)
        
        if df is not None:
            # Obtener fechas únicas para el selector
            fechas = sorted(df['FECHA'].dt.strftime('%Y-%m-%d').unique().tolist())
            departamentos = sorted(df['DEPARTAMENTO'].unique().tolist())
            
            return jsonify({
                'status': 'success',
                'cache_key': cache_key,
                'fechas': fechas,
                'departamentos': departamentos,
                'total_registros': len(df)
            })
        else:
            return jsonify({'error': 'Error al procesar el archivo'}), 500
    
    return jsonify({'error': 'Formato de archivo no soportado'}), 400

# Ruta para obtener predicción
@app.route('/api/predict', methods=['POST'])
def predict():
    data = request.get_json()
    cache_key = data.get('cache_key')
    fecha = data.get('fecha')
    departamento = data.get('departamento')
    
    if not all([cache_key, fecha, departamento]):
        return jsonify({'error': 'Faltan parámetros requeridos'}), 400
    
    cache_path = os.path.join(app.config['CACHE_FOLDER'], f"{cache_key}.pkl")
    
    if not os.path.exists(cache_path):
        return jsonify({'error': 'Datos no encontrados en caché'}), 404
    
    try:
        df = joblib.load(cache_path)
        
        # Filtrar por departamento
        df_depto = df[df['DEPARTAMENTO'] == departamento].copy()
        
        if df_depto.empty:
            return jsonify({'error': 'No se encontraron datos para el departamento especificado'}), 404
        
        # Convertir la fecha de string a datetime
        fecha_dt = pd.to_datetime(fecha)
        
        # Aquí iría la lógica de predicción
        # Por ahora, devolvemos los datos históricos para la fecha seleccionada
        resultado = df_depto[df_depto['FECHA'].dt.date == fecha_dt.date()].to_dict('records')
        
        if not resultado:
            return jsonify({
                'status': 'success',
                'mensaje': 'No hay datos históricos para la fecha seleccionada',
                'datos': None
            })
        
        return jsonify({
            'status': 'success',
            'datos': resultado[0]  # Devolver el primer registro que coincida
        })
        
    except Exception as e:
        print(f"Error en la predicción: {str(e)}")
        return jsonify({'error': str(e)}), 500

# Ruta para servir la aplicación frontend
@app.route('/')
def serve():
    return send_from_directory(app.static_folder, 'index.html')

if __name__ == '__main__':
    app.run(debug=True, port=5000)
