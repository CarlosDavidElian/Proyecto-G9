# Backend de Procesamiento de Datos
Este es el backend para el procesamiento de datos de radiación solar. Incluye un servidor Flask que maneja la carga de archivos Excel, procesamiento de datos y almacenamiento en caché.

## Requisitos
- Python 3.8 o superior
- pip (gestor de paquetes de Python)

## Instalación
1. Crea un entorno virtual (recomendado):
   ```
   python -m venv venv
   .\venv\Scripts\activate  # En Windows
   ```

2. Instala las dependencias:
   ```
   pip install -r requirements.txt
   ```

## Uso
1. Inicia el servidor:
   ```
   python app.py
   ```

2. El servidor estará disponible en `http://localhost:5000`

## Endpoints
- `POST /api/upload`: Sube un archivo Excel para procesar
- `POST /api/predict`: Obtiene predicciones basadas en los datos cargados

## Estructura de Carpetas
- `uploads/`: Almacena los archivos subidos
- `cache/`: Almacena los datos procesados en caché

## Variables de Entorno
Crea un archivo `.env` en la raíz del proyecto con las siguientes variables si es necesario:

```
FLASK_APP=app.py
FLASK_ENV=development
```
